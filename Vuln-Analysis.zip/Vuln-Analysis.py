import pandas as pd
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Load the data with comma delimiter
file_path = 'MLDATA.csv'
data = pd.read_csv(file_path, delimiter=',')

# Filter the data for hosts with successful brute force attacks
brute_forced_hosts = data[data['Successful Brute Force Attacks'] > 0].copy()

# Convert open ports and brute-forced ports to lists of integers
brute_forced_hosts['Open ports'] = brute_forced_hosts['Open ports'].apply(lambda x: list(map(int, x.strip('[]').split(','))))
brute_forced_hosts['Successfully Brute-Forced Ports'] = brute_forced_hosts['Successfully Brute-Forced Ports'].apply(lambda x: list(map(int, x.strip('[]').split(','))))

# Combine open ports and brute-forced ports for clustering
brute_forced_hosts['All Ports'] = brute_forced_hosts.apply(lambda row: row['Open ports'] + row['Successfully Brute-Forced Ports'], axis=1)

# Encode the ports using MultiLabelBinarizer
mlb = MultiLabelBinarizer()
encoded_ports = mlb.fit_transform(brute_forced_hosts['All Ports'])

# Apply K-Means clustering
kmeans = KMeans(n_clusters=3, random_state=42)
brute_forced_hosts['Cluster'] = kmeans.fit_predict(encoded_ports)

# Calculate the most frequent open ports
most_frequent_open_ports = brute_forced_hosts['Open ports'].explode().value_counts().head(10)

# Correlation analysis between Exploitable Vulnerabilities and Successfully Brute-Forced Ports
brute_forced_hosts['Num Successfully Brute-Forced Ports'] = brute_forced_hosts['Successfully Brute-Forced Ports'].apply(len)
correlation = brute_forced_hosts[['Exploitable Vulnerabilities', 'Num Successfully Brute-Forced Ports']].corr().iloc[0, 1]

# Plotting the clusters
plt.figure(figsize=(10, 6))
for cluster in brute_forced_hosts['Cluster'].unique():
    subset = brute_forced_hosts[brute_forced_hosts['Cluster'] == cluster]
    plt.scatter(subset.index, subset['Successful Brute Force Attacks'], label=f'Cluster {cluster}')
plt.xlabel('Host Index')
plt.ylabel('Successful Brute Force Attacks')
plt.title('Clustering of Hosts Based on Open Ports and Successfully Brute-Forced Ports')
plt.legend()

# Save the plot as an image file
plot_filename = "vuln_analysis.png"
plt.savefig(plot_filename)
#plt.show()

# Display the most frequent open ports
print("Most Frequent Open Ports on Hosts with Successful Brute Force Attacks:")
print(most_frequent_open_ports)

# Display the correlation result
print(f"\nCORRELATION between Exploitable Vulnerabilities and Number of Successfully Brute-Forced Ports: {100 * correlation:.2f}%")