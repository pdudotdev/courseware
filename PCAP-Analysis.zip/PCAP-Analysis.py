import pandas as pd
from scapy.all import rdpcap
from scapy.layers.inet import IP, TCP
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import numpy as np
from collections import defaultdict
import matplotlib.pyplot as plt
from datetime import datetime

def read_pcap(file_path):
    """
    Reads a pcap file and returns a list of packets.
    
    Args:
    file_path (str): The path to the pcap file.
    
    Returns:
    packets (list): List of packets read from the pcap file.
    """
    packets = rdpcap(file_path)
    #print(packets[0])
    return packets

def extract_features(packets):
    """
    Extracts relevant features from the packets for clustering.
    
    Args:
    packets (list): List of packets.
    
    Returns:
    features (list): Extracted features including source IP, destination IP, source port, destination port,
                     number of connection attempts, average interval between attempts, and timestamp.
    """
    connection_attempts = defaultdict(list)
    target_ports = {22, 23, 5900, 5901, 5902, 5903}
    
    # Loop through each packet in the packets list
    for packet in packets:
        if IP in packet and TCP in packet:
            dst_port = packet[TCP].dport
            if dst_port in target_ports:
                src_ip = packet[IP].src
                dst_ip = packet[IP].dst
                src_port = packet[TCP].sport
                timestamp = float(packet.time)  # Convert timestamp to float
                
                key = (src_ip, dst_ip, src_port, dst_port)
                connection_attempts[key].append(timestamp)
    
    features = []
    # Loop through each connection attempt key and its timestamps
    for key, timestamps in connection_attempts.items():
        src_ip, dst_ip, src_port, dst_port = key
        
        count = len(timestamps)
        if count > 1:
            intervals = np.diff(sorted(timestamps))
            avg_interval = np.mean(intervals)
            max_interval = np.max(intervals)
        else:
            avg_interval = 0
            max_interval = 0
        
        first_timestamp = sorted(timestamps)[0]
        features.append([src_ip, dst_ip, src_port, dst_port, count, avg_interval, max_interval, first_timestamp])
    
    return features

def preprocess_data(features):
    """
    Preprocesses the data by converting it into a DataFrame and scaling the numeric features.
    
    Args:
    features (list): List of extracted features.
    
    Returns:
    scaled_features (ndarray): Scaled numeric features.
    df (DataFrame): DataFrame containing the original features.
    """
    df = pd.DataFrame(features, columns=['src_ip', 'dst_ip', 'src_port', 'dst_port', 'count', 'avg_interval', 'max_interval', 'timestamp'])
    
    # Convert timestamp to datetime format
    df['timestamp'] = df['timestamp'].apply(lambda ts: datetime.fromtimestamp(ts))
    #print(df)

    df_numeric = df[['count', 'avg_interval', 'max_interval']]  # Select numeric columns for clustering
    scaler = StandardScaler()
    scaled_features = scaler.fit_transform(df_numeric)
    return scaled_features, df

def apply_kmeans(scaled_features, n_clusters=3):
    """
    Applies K-Means clustering to the scaled features.
    
    Args:
    scaled_features (ndarray): Scaled numeric features.
    n_clusters (int): Number of clusters to form.
    
    Returns:
    labels (ndarray): Cluster labels for each data point.
    """
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    kmeans.fit(scaled_features)
    labels = kmeans.labels_
    return labels

def identify_anomalies(df):
    """
    Identifies anomalies based on clusters with high connection counts and short intervals.
    
    Args:
    df (DataFrame): DataFrame containing the features and cluster labels.
    
    Returns:
    anomalies (DataFrame): DataFrame containing the anomalies.
    """
    # Adjusted criteria for anomalies
    high_count_threshold = df['count'].quantile(0.50)  # 50th percentile (median)
    short_interval_threshold = df['avg_interval'].quantile(0.50)  # 50th percentile (median)
    anomalies = df[(df['count'] > high_count_threshold) & (df['avg_interval'] < short_interval_threshold)]
    return anomalies

def plot_clusters(df, scaled_features, labels):
    """
    Plots the clusters using a scatter plot, highlighting the anomalies.
    
    Args:
    df (DataFrame): DataFrame containing the original features and cluster labels.
    scaled_features (ndarray): Scaled numeric features.
    labels (ndarray): Cluster labels for each data point.
    """
    anomalies = df[df['anomaly'] == 1]
    normal = df[df['anomaly'] == 0]
    
    plt.figure(figsize=(10, 7))
    
    # Add jitter to the points (to better see the anomalies on the chart instead of just one red X representing all)
    jitter = 0.05
    
    # Plot normal points
    plt.scatter(scaled_features[normal.index, 0] + np.random.uniform(-jitter, jitter, size=normal.shape[0]), 
                scaled_features[normal.index, 1] + np.random.uniform(-jitter, jitter, size=normal.shape[0]), 
                c='blue', label='Normal')
    
    # Plot anomaly points
    plt.scatter(scaled_features[anomalies.index, 0] + np.random.uniform(-jitter, jitter, size=anomalies.shape[0]), 
                scaled_features[anomalies.index, 1] + np.random.uniform(-jitter, jitter, size=anomalies.shape[0]), 
                c='red', label='Anomaly', marker='x')
    
    plt.title('K-Means Clustering of Network Traffic')
    plt.xlabel('Count')
    plt.ylabel('Avg Interval')
    plt.legend()
    plt.savefig('Traffic_Clusters.png')

def main(file_path):
    """
    Main function that reads the pcap file, extracts features, preprocesses data,
    applies K-Means clustering, identifies anomalies, and plots the clusters.
    
    Args:
    file_path (str): The path to the pcap file.
    """
    packets = read_pcap(file_path)
    features = extract_features(packets)
    #print("Extracted Features:")
    #print(features)  # Print extracted features to debug

    if not features:
        print("No features extracted. Check the pcap file and extraction logic.")
        return
    
    scaled_features, df = preprocess_data(features)
    #print("Preprocessed Data:")
    #print(df.head())  # Print preprocessed data to debug
    
    labels = apply_kmeans(scaled_features)
    df['label'] = labels  # Add cluster labels to the DataFrame
    #print("Cluster Labels:")
    #print(df['label'].value_counts())  # Print cluster label counts to debug

    anomalies = identify_anomalies(df)
    
    # Mark anomalies in the DataFrame
    df['anomaly'] = 0
    df.loc[anomalies.index, 'anomaly'] = 1       
    anomalies.to_excel('Anomalies.xlsx')  # Save the anomalies DataFrame to Excel in the current directory

    # Print only specific columns from the anomalies DataFrame
    print("\nDetected Anomalies:")
    anomalies = anomalies.copy()  # Avoid SettingWithCopyWarning
    anomalies['timestamp'] = anomalies['timestamp'].apply(lambda ts: ts.strftime('%Y-%m-%d %H:%M:%S'))
    print(anomalies[['src_ip', 'dst_ip', 'src_port', 'dst_port', 'timestamp']].to_string(index=False))  # Print anomalies DataFrame without index
    
    plot_clusters(df, scaled_features, labels) # Plot the clusters

file_path = "my_ssh_capture.pcap"  # Replace with the path to your pcap file
main(file_path)